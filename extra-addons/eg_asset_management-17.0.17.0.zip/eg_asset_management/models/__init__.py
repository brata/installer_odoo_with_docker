from . import asset_detail
from . import asset_move
from . import asset_location
from . import asset_category